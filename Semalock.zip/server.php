<?php

/**
 * Router localhost untuk StudyFlow (PHP built-in server).
 *
 * Di produksi (hosting Apache), perilaku URL ditentukan oleh tiga berkas
 * .htaccess + DirectoryIndex:
 *   public/.htaccess           : / -> /home/ (301); /home* & /passcreator* ->
 *                                front controller Laravel; dan fallback situs.
 *   public/studyflow/.htaccess : /studyflow/* (non-berkas) -> Laravel.
 *
 * Berkas ini dipakai OTOMATIS oleh `php artisan serve` — ServeCommand memeriksa
 * base_path('server.php') lebih dulu, dan HANYA memakai router bawaan framework
 * kalau berkas ini tidak ada. Router bawaan itu memotong permintaan apa pun yang
 * cocok dengan berkas/direktori nyata di public/ (return false), yang membuat:
 *   /home        -> dilayani sebagai direktori (404, tak ada index.html)
 *   /studyflow/  -> diambil public/studyflow/index.php yang `$root`-nya
 *                   masih hard-code untuk hosting (fatal 500 di localhost).
 *
 * Berkas ini meniru aturan .htaccess persis, lalu mengarahkan semua rute lewat
 * front controller asli public/index.php (yang sudah menormalisasi SCRIPT_NAME
 * agar /studyflow/* tidak terpotong base URL-nya).
 *
 * Jalankan dengan:
 *   php artisan serve
 *
 * Perintah lama  `php -S 127.0.0.1:8000 -t public server.local.php`  tetap bisa:
 * server.local.php hanyalah shim yang meneruskan ke berkas ini.
 */

declare(strict_types=1);

$publicPath = __DIR__ . '/public';
$uri = urldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// 1. Akar domain -> /home/ (persis public/.htaccess: RewriteRule ^$ /home/ [R=301,L]).
if ($uri === '/') {
    header('Location: /home/', true, 301);
    exit;
}

// 2. Rute situs yang harus lewat Laravel walau /home ada sebagai folder.
//    (public/.htaccess baris 6-9, termasuk URL lama * .html).
$siteRoutes = [
    '/home',
    '/home/',
    '/home/passcreator',
    '/home/passcreator/',
    '/home/index.html',
    '/home/PassCreator.html',
    '/home/passcreator.html',
    '/home/PassCreator',
    '/passcreator',
    '/passcreator/',
    '/semalock',
    '/semalock/',
];
if (in_array($uri, $siteRoutes, true)) {
    require $publicPath . '/index.php';
    return;
}

// 3. Aplikasi StudyFlow (/studyflow dan /studyflow/*). Berkas aset yang ada
//    (assets/*.js, *.css) dilayani langsung; sisanya ke front controller Laravel.
if ($uri === '/studyflow' || str_starts_with($uri, '/studyflow/')) {
    if (is_file($publicPath . $uri)) {
        return false; // aset statis
    }
    require $publicPath . '/index.php';
    return;
}

// 4. Berkas statis lain yang memang ada (favicon, robots.txt, /home/profile.avif,
//    404.html, dll.): biarkan built-in server yang melayani.
if (is_file($publicPath . $uri)) {
    return false;
}

// 5. Sisanya lewat Laravel -> fallback 404 situs (SiteController::notFound).
require $publicPath . '/index.php';